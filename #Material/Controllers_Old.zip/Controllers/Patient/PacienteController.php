<?php

namespace App\Controllers\Patient;

use App\classes\Export;
use App\classes\FileManager;
use App\classes\Password;
use App\Dao\Entity\PacienteEntity;
use App\Dao\Entity\UserEntity;
use App\Dao\Models\Especialidade;
use App\Dao\Models\Paciente;
use App\Dao\Models\Provincia;
use App\Dao\Models\User;
use App\export\Csv;
use App\export\ExportCsv;
use App\export\ExportPdf;
use App\export\Pdf;
use App\Http\BaseController as Controller;
use App\Http\Request;
use App\library\PostOld;
use App\trait\DocumentExport;
use Dom\Entity;

class PacienteController extends Controller
{

   use DocumentExport;

   // Métodos padrão de controllers RESTful
   public function index()
   {

      // Listar recursos
      $paciente = new Paciente();

      $model = $paciente->select("pacientes.*, usuarios.nome as usuario, usuarios.email as email, usuarios.genero as genero")
         ->join(User::class, 'pacientes.usuario_id', '=', 'usuarios.id')
         ->paginate(5);
      $pacientes = $model->Items ?? [];
      unset($model->Items);
      $data = [
         'pacientes' => $pacientes,
         'title' => 'Todos Pacientes',
         'tools' => $model,
         'description' => 'Gerir Pacientes',
         'keywords' => 'Gerir, Pacientes, Listar'
      ];

      $this->view(globals($data), 'admin.pacientes');
   }

   public function show($params)
   {
   header(API);
      $model = new Paciente()
      ->
       select(
         "pacientes.*, usuarios.nome as nome, 
   usuarios.email as email, provincias.nome provincia"
   ) 
     ->where('pacientes.id', '=', $params['paciente'])
          ->join(User::class, 'pacientes.usuario_id', '=', 'usuarios.id')
         ->join(Provincia::class, 'pacientes.provincia_id', '=', 'provincias.id')
         ->first();


      echo  json_encode(convertData($model), true);
      // Exibir recurso específico

   }

   public function create()
   {
      // Exibir formulário para criar novo recurso
      $provincias = (new Provincia())->select()->orderBy('nome')->get();
      $data = [
         'title' => 'Criar Novo Paciente',
         'description' => 'Gerir Pacientes',
         'keywords' => 'Gerir, Pacientes, Listar',
         'provincias' => $provincias
      ];
      $this->view(globals($data), 'admin.criar-paciente');
   }

   /* public function store()
   {
      // Salvar novo recurso
      $usermodel = new User(UserEntity::class);
      $pacienteModel = new Paciente(PacienteEntity::class);
      $data = sanitizeInput(filter_input_array(INPUT_POST, FILTER_DEFAULT));
      $data['perfil'] = 'paciente';

      array_filter($data, function ($input) use ($data) {
         if (empty($input)) {
            PostOld::set($data);
            redirect("admin/paciente-criar", ['error', 'Campos Obrigatorios', 'danger']);
         }
      });
      //Usuario do paciente
      $usermodel->setEntity()->nome =  $data['nome'];
      $usermodel->setEntity()->email =  $data['email'];
      $usermodel->setEntity()->perfil =  $data['perfil'];

      $usermodel->setEntity()->senha_gerada =  1;
      // gerar senha
      $senha = Password::generate(2);
      $usermodel->setEntity()->senha = Password::hash($senha);
      $pacienteModel = new Paciente(PacienteEntity::class);

      (new FileManager())->add([
         'email' => $data['email'],
         'senha' => $senha
      ]);

      unset($data['nome']);
      unset($data['email']);
      unset($data['perfil']);

      //Dados Medicas
      entity_data_itera($data, $pacienteModel);

      //Armazenar Usuario paciente
      $userStore = $usermodel->store();

      if ($usermodel) {
      $pacienteModel->setEntity()->usuario_id = (int) $userStore;

      // dd($pacienteModel);
      //Armazenar Dados paciente
      $pacienteStore = $pacienteModel->store();

      PostOld::clean();

      if ($pacienteStore) {
         redirect('admin/pacientes', ['success', 'paciente Registrado com sucesso']);
      } else {
         redirect('admin/pacientes', ['error', 'Paciente não Cadastrado']);
      }
       } else {
         redirect('admin/pacientes', ['error', 'Usuario não Cadastrado']);
      } 
   } */


   public function store()
   {
      // Instanciar modelos
      $usermodel = new User(UserEntity::class);
      $pacienteModel = new Paciente(PacienteEntity::class);

      // Obter e sanitizar dados do formulário
      $data = sanitizeInput(filter_input_array(INPUT_POST, FILTER_DEFAULT));

      $data['perfil'] = 'paciente';

      // Validação de campos obrigatórios
      foreach ($data as $input) {
         if (empty($input)) {
            PostOld::set($data);
            redirect("admin/paciente-criar", ['error', 'Todos os campos são obrigatórios', 'danger']);
         }
      }

      // Validar e-mail
      if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
         PostOld::set($data);
         redirect("admin/paciente-criar", ['error', 'E-mail inválido', 'danger']);
      }

      // Verificar se e-mail já está cadastrado
      if ($usermodel->findByEmail($data['email'])) {
         PostOld::set($data);
         redirect("admin/paciente-criar", ['error', 'E-mail já está em uso', 'danger']);
      }

      // Configurar entidade do usuário
      $user = $usermodel->setEntity();
      $user->nome = $data['nome'];
      $user->email = lower($data['email']);
      $user->perfil = $data['perfil'];
      $user->genero = $data['genero'];
      $user->senha_gerada = 1;

      // Gerar senha aleatória (mínimo 6 caracteres)
      $senha = Password::generate(2);
      /*    if (strlen($senha) < 6) {
         // Garante que a senha gerada tenha no mínimo 6 caracteres
         $senha .= rand(1000, 9999);
      } */
      $user->senha = Password::hash($senha);


      // Salvar senha visível (atenção em produção)
      (new FileManager())->add([
          'email' => $user->email,
          'senha' => $senha
       ]);
      // Remover dados já usados
      unset($data['nome'], $data['email'], $data['perfil'], $data['genero']);

      // Preencher dados médicos
      entity_data_itera($data, $pacienteModel);
      // Salvar usuário
      $userStore = $usermodel->store();

      if ($userStore) {
         // Associar usuário ao paciente
         $paciente = $pacienteModel->setEntity();
         $paciente->usuario_id = (int) $userStore;
         $paciente->code = gerarCodigo();


         // Salvar paciente
         $pacienteStore = $pacienteModel->store();

         PostOld::clean();

         if ($pacienteStore) {
            redirect('admin/pacientes', ['success', 'Paciente registrado com sucesso']);
         } else {
            redirect('admin/pacientes', ['error', 'Paciente não cadastrado']);
         }
      } else {
         redirect('admin/pacientes', ['error', 'Usuário não cadastrado']);
      }
   }

   public function edit($params)
   {

      // Editar recurso existente
      $id = (int) $params['paciente-editar'];
      $model = new Paciente()->select("pacientes.*, usuarios.nome as nome, usuarios.email as email, usuarios.genero as genero, provincias.nome provincia")
         ->where('pacientes.id', '=', $id)
         ->join(User::class, 'pacientes.usuario_id', '=', 'usuarios.id')
         ->join(Provincia::class, 'pacientes.provincia_id', '=', 'provincias.id')
         ->first();
      // $any = (new User())->findById($id, "Count(*) as total");
      // dd($model);



      // dd($any->total);
      $data = [
         'paciente' => $model,
         'provincias'=> new Provincia()->all(),
         'title' => 'Editar Usuario ',
         'description' => 'Editar O Usuario',
         'keywords' => 'Editar, Usuario, Alterar',


      ];
      $this->view(globals($data), 'admin.paciente-edit');
   }

   public function update($params)
   {
      $data = sanitizeInput(filter_input_array(INPUT_POST, FILTER_DEFAULT));

      // Atualizar recurso existente
        $id = (int) $data['id'];

      if ($id === 0) {
         redirect('admin/pacientes', ['error', 'Paciente não encontrado', 'danger']);
      }


      $pacienteModel = new Paciente(PacienteEntity::class);
      $userModel = new User(UserEntity::class);

      $paciente = $pacienteModel->findById($id);
      if (!$paciente) {
         redirect('admin/pacientes', ['error', 'Paciente não encontrado', 'danger']);
      }

      // array_filter($data, function ($input) use ($data) {
      //    if (empty($input)) {
      //       PostOld::set($data);
      //       redirect("admin/Paciente-editar/{$data['id']}", ['error', 'Campos Obrigatorios', 'danger']);
      //    }
      // });


      // Atualizar dados do usuário
      $usuario = $userModel->findById($paciente->usuario_id);
      if ($usuario) {
         $uEntity= $userModel->setEntity();
         // $pEntity= $userModel->setEntity();
         $uEntity->id = $usuario->id;
         $userDate= sepatateDate($data, $userModel->fillable);

        entity_itera($userDate, $uEntity);
         $userModel->save();
      }

      unset($data['nome'], $data['email'], $data['genero']);
      // unset();
      $pEntity=$pacienteModel->setEntity();

      // Atualizar dados do Paciente
      $pEntity->id = $id;

      $pacienteDate= sepatateDate($data, $pacienteModel->fillable);
      $pEntity->usuario_id = $paciente->usuario_id;
      entity_itera($pacienteDate, $pEntity);
      // dd($pacienteModel);
      $updated = $pacienteModel->save();
      // dd($updated);

      PostOld::clean();
      // dd($pacienteModel);
      if ($updated) {
         redirect('admin/pacientes', ['success', 'Paciente atualizado com sucesso']);
      } else {
         redirect('admin/pacientes', ['error', 'Falha ao atualizar Paciente']);
      }

   }

   public function delete($params)
   {

      // Deletar recurso
   }

   public function exporte()
   {

      //Exportar
      //conjunto a ser exportados
      $types = ['pdf', 'csv', 'excel'];

      $type = sanitizeInput($_GET['type']);
      if (!isset($type) && $type === null) {
         throw new \Exception("O tipo não foi definido");
      }

      if (!in_array($type, $types)) {
         throw new \Exception(sprintf('O tipo %s não se encontra no conjunto', $type));
      }

      $paciente = new Paciente();
      $model = $paciente->select("pacientes.*, usuarios.nome as usuario, usuarios.email as email, usuarios.genero as genero, provincias.nome provincia")
         ->join(User::class, 'pacientes.usuario_id', '=', 'usuarios.id')
         ->join(Provincia::class, 'pacientes.provincia_id', '=', 'provincias.id')->get();
      // Dados para o relatório
      //
      $data = [];
      //a View do PDF
      $data['view'] = 'document.pacientes';

      //Os dados do relatório para view 
      $data['data'] = [
         'title' => 'Relatório de Pacientes',
         'description' => 'Lista de Pacientes',
         'keywords' => 'Relatório, Pacientes, Lista',
         'pacientes' => $model,
         'total' => count($model),
         'date' => date('d/m/Y'),
         'hour' => date('H:i:s'),
         'hospital' => HOSPITAL
      ];

      //Nome do Arquivo 
      $data['nome_arquivo'] = "pacientes". date('YmdHis') ;
      //Download DPF
      $data['download'] = true;

      $data['model'] = convertData($model);

      //==============================================================================
      // Exportação
      //==============================================================================
      $this->export($data, $type);
   }
}