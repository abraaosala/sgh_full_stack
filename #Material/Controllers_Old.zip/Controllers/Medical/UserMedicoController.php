<?php

namespace App\controllers;

use App\classes\Session;
use App\Dao\Models\Consulta;
use App\Dao\Models\Paciente;
use App\Dao\Models\User;
use App\Http\BaseController as Controller;


//Controlado do Usuario com Perfil Medico /medico
class UserMedicoController extends Controller
{
   // Métodos padrão de controllers RESTful
   public function index()
   {
      //Consultar O perfil
      $userperfil = userPerfil(session()->get('id'), session()->get('perfil'));
      // dd($userperfil);
      if ($userperfil) {
         $pId = $userperfil->id;
         $count_pa = new Paciente()
            ->select("Count(*) as total")
            ->where('medico_id', '=', $pId)
            ->first();
         // quantidades de consultas agendadas

         // dd($count_pa);
         // dd();
         $model = new Consulta();
         $result = $model->select('Count(*) as total')
            ->whereGroup(
               [['medico_id', '=', $pId], ['status', '=', 'AG']]
            )
            ->first();

         //  dd($result);



      }

      // Painel Administrativo 
      $this->view(globals(
         [
            'title' => 'Painel do Medico',
            'count' => $count_pa->total ?? 0,
            'count_consultas' => $result->total
         ]
      ), 'pages.dashboard');
   }

   public function show($params)
   {

      // Exibir recurso específico

   }

   public function create()
   {
      // criar novo recurso
   }

   public function store()
   {

      // Salvar novo recurso

   }

   public function edit($params)
   {

      // Editar recurso existente

   }

   public function update($params)
   {

      // Atualizar recurso existente
   }

   public function delete($params)
   {

      // Deletar recurso
   }

   public function list (){


   }
}