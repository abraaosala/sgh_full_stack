<?php

namespace App\Controllers\Medical;

use App\classes\FileManager;
use App\classes\Password;
use App\Dao\Entity\MedicoEntity;
use App\Dao\Entity\UserEntity;
use App\Dao\Models\Especialidade;
use App\Dao\Models\Medico;
use App\Dao\Models\Provincia;
use App\Dao\Models\User;
use App\Http\BaseController as Controller;
use App\library\PostOld;
use App\trait\DocumentExport;

class MedicoController extends Controller
{
   use DocumentExport;

   // Métodos padrão de controllers RESTful
   public function index()
   {  
      $medico = (new Medico());
      $model = $medico
         ->select("medicos.*, usuarios.nome as usuario, usuarios.email as email, especialidades.nome as especialidade")
         ->join(User::class, 'medicos.usuario_id', '=', 'usuarios.id')
         ->join(Especialidade::class, 'medicos.especialidade_id', '=', 'especialidades.id')
         ->paginate(5);
      $medicos =  $model->Items;
      unset($model->Items);
      // Listar recursos
      $data = [
         'medicos' => $medicos,
         'title' => 'Todos Medicos',
         'tools' => $model,
         'description' => 'Gerir Medicos',
         'keywords' => 'Girir, Medicos, Listar'

      ];

      $this->view(globals($data), 'admin.medicos');
   }

   public function create()
   {
      $provincias = (new Provincia())->select()->orderBy('nome')->get();
      $especialidades = (new Especialidade())->select()->orderBy('nome')->get();
      $data = [
         'title' => 'Criar Novo Medico',
         'description' => 'Gerir Medicos',
         'keywords' => 'Girir, Medicos, Listar',
         'provincias' => $provincias,
         'especialidades' => $especialidades

      ];
      $this->view(globals($data), 'admin.criar-medico');
   }

   public function show($params)
   {

      $model = new Medico()->select(
         "medicos.*, usuarios.nome as nome, 
                  usuarios.email as email, especialidades.nome 
                  as especialidade, provincias.nome provincia"
      )
         ->where('medicos.id', '=', $params['medico'])
         ->join(User::class, 'medicos.usuario_id', '=', 'usuarios.id')
         ->join(Especialidade::class, 'medicos.especialidade_id', '=', 'especialidades.id')
         ->join(Provincia::class, 'medicos.provincia_id', '=', 'provincias.id')
         ->first();


      echo  json_encode(convertData($model), true);
      // Exibir recurso específico

   }

   public function store()
   {
      // Salvar novo recurso

      $usermodel = new User(UserEntity::class);
      $medicomodel = new Medico(MedicoEntity::class);
      $data = sanitizeInput(filter_input_array(INPUT_POST, FILTER_DEFAULT));
      $data['perfil'] = 'medico';
      // dd($data);


      // array_filter($data, function ($input) use ($data) {
      //    if (empty($input)) {
      //       PostOld::set($data);
      //       redirect("admin/medico-criar", ['error', 'Campos Obrigatorios', 'danger']);
      //    }
      // });



      if ($usermodel->unique($data['email'], 'email')) {
         # code...
         redirect('admin/medico-criar', ['error', 'Usuario já está Cadastrado', 'danger']);
         die;
      }

      $usermodel->setEntity();

      //Usuario do medico
      $usermodel->setEntity()->nome =  $data['nome'];
      $usermodel->setEntity()->email =  $data['email'];
      $usermodel->setEntity()->perfil =  $data['perfil'];
      $usermodel->setEntity()->genero =  $data['genero'];
      $usermodel->setEntity()->senha_gerada =  1;

      // gerar senha
      $senha = Password::generate(2);
      $usermodel->setEntity()->senha = Password::hash($senha);
      $file = manager();

      // Apenas em ambiente de testes — nunca em produção
      if (!$file->exists('email', $data['email'])) {
         # code...
         $file->add([
            'email' => $data['email'],
            'senha' => $senha
         ]);
      }


      unset($data['nome'], $data['email'], $data['perfil'], $data['genero']);

      //Dados Medicas
      entity_data_itera($data, $medicomodel);

      // Iniciar transação (se disponível)
      // $usermodel->beginTransaction();

      //Armazenar Usuario Medico
      $userStore = $usermodel->store();
      if ($usermodel) {
         $medicomodel->setEntity()->usuario_id = (int) $userStore;

         //Armazenar Dados Medico
         $medicoStore = $medicomodel->store();

         if ($medicoStore) {
            redirect('admin/medicos', ['success', 'Medico Registrado com sucesso']);
         } else {
            redirect('admin/medicos', ['error', 'Medico não Cadastrado']);
         }
      } else {
         redirect('admin/medicos', ['error', 'Usuario não Cadastrado']);
      }


      // Salvar novo recurso

   }

   public function stored() {}

   public function edit($params)
   {

      // PostOld::clean();
      // Editar recurso existente
      $id = (int) $params['medico-editar'];
      if ($id === 0) {
         redirect('admin/medicos', ['error', 'Medico não encontrado']);
      }

      $medico = (new Medico())->select()->where('id', '=', $id)->first();
      // dd($medico);
      $usuario = (new User())->findById($medico->usuario_id);
      $especialidade = (new Especialidade())->findById($medico->especialidade_id);
      $provincia = (new Provincia())->findById($medico->provincia_id);


      if (!$medico) {
         redirect('admin/medicos', ['error', 'Medico não encontrado']);
      }

      $medico->usuario = $usuario;
      $medico->especialidade = $especialidade;
      $medico->provincia = $provincia;

      $provincias = (new Provincia())->select()->orderBy('nome')->get();
      $especialidades = (new Especialidade())->select()->orderBy('nome')->get();
      $data = [
         'title' => 'Editar Medico',
         'description' => 'Gerir Medicos',
         'keywords' => 'Girir, Medicos, Listar',
         'medico' => $medico,
         'provincias' => $provincias,
         'especialidades' => $especialidades
      ];
      $this->view(globals($data), 'admin.medico-editar');
   }

   public function update($params)
   {
      // Atualizar recurso existente
      $id = (int) $params['medico-update'];
      if ($id === 0) {
         redirect('admin/medicos', ['error', 'Medico não encontrado']);
      }

      $medicoModel = new Medico(MedicoEntity::class);
      $userModel = new User(UserEntity::class);
      // $newUserModel = new User(UserEntity::class);
      // $newMedicoModel = new Medico(MedicoEntity::class);

      $medico = $medicoModel->findById($id);
      if (!$medico) {
         redirect('admin/medicos', ['error', 'Medico não encontrado']);
      }

      $data = sanitizeInput(filter_input_array(INPUT_POST, FILTER_DEFAULT));
      // array_filter($data, function ($input) use ($data) {
      //    if (empty($input)) {
      //       PostOld::set($data);
      //       redirect("admin/medico-editar/{$data['id']}", ['error', 'Campos Obrigatorios', 'danger']);
      //    }
      // });

      // Atualizar dados do usuário
      $usuario = $userModel->findById($medico->usuario_id);
      if ($usuario) {
         $userModel->setEntity()->id = $usuario->id;
         $userModel->setEntity()->nome = $data['nome'];
         $userModel->setEntity()->email = $data['email'];
         $userModel->setEntity()->genero = $data['genero'];
         $userModel->save();
      }

      unset($data['nome'], $data['email'], $data['genero']);
      // unset();
      $mEntity = $medicoModel->setEntity();

      // Atualizar dados do médico
      $mEntity->id = $id;
      $mEntity->usuario_id = $medico->usuario_id;
      entity_itera($data, $mEntity);
      $updated = $medicoModel->save();
      // dd($updated);

      PostOld::clean();
      // dd($medicoModel);
      if ($updated) {
         redirect('admin/medicos', ['success', 'Medico atualizado com sucesso']);
      } else {
         redirect('admin/medicos', ['error', 'Falha ao atualizar medico']);
      }
   }

   public function delete($params)
   {

      // Deletar recurso
   }

   public function exporte()
   {

      //Exportar
      //conjunto a ser exportados
      $types = ['pdf', 'csv', 'excel'];

      $type = sanitizeInput($_GET['type']);

      if (!isset($type) && $type === null) {
         throw new \Exception("O tipo não foi definido");
      }

      if (!in_array($type, $types)) {
         throw new \Exception(sprintf('O tipo %s não se encontra no conjunto', $type));
      }

      $paciente = new Medico();
      $model = $paciente
         // ->select("medicos.*, usuarios.nome as usuario, usuarios.email as email, usuarios.genero as genero, usuarios.data_nascimento, provincias.nome provincia")
         ->select("medicos.id,usuarios.nome as nome, usuarios.email as email,medicos.telefone, medicos.numero_ordem,medicos.nivel, usuarios.genero as genero, usuarios.data_nascimento, provincias.nome provincia")
         ->join(User::class, 'medicos.usuario_id', '=', 'usuarios.id')
         ->join(Provincia::class, 'medicos.provincia_id', '=', 'provincias.id')->get();
      // Dados para o relatório
      //
      $data = [];
      //a View do PDF
      $data['view'] = 'document.medicos';

      //Os dados do relatório para view 
      $data['data'] =
         [
            'title' => 'Relatório de medicos',
            'description' => 'Lista de medicos',
            'keywords' => 'Relatório, medicos, Lista',
            'lists' => $model,
            'total' => count($model),
            'date' => date('d/m/Y'),
            'hour' => date('H:i:s'),
            'hospital' => HOSPITAL
         ];

      //Nome do Arquivo 
      $data['nome_arquivo'] = "medicos" . date('YmdHis');
      //Download DPF
      $data['download'] = false;

      $data['model'] = convertData($model);

      //==============================================================================
      // Exportação
      //==============================================================================
      $this->export($data, $type);
   }
}